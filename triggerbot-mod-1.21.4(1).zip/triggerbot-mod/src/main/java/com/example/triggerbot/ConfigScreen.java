package com.example.triggerbot;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;

public class ConfigScreen extends Screen {

    private final Screen parent;

    public ConfigScreen(Screen parent) {
        super(Text.literal("TriggerBot"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        TriggerBotConfig c = TriggerBotConfig.INSTANCE;
        int w = 200;
        int x = this.width / 2 - w / 2;
        int y = this.height / 4 - 10;
        int step = 24;

        addDrawableChild(ButtonWidget.builder(label("Estado", c.enabled), b -> {
            c.enabled = !c.enabled;
            b.setMessage(label("Estado", c.enabled));
        }).dimensions(x, y, w, 20).build());

        addDrawableChild(new ValueSlider(x, y + step, w, 20, "Dano", 0.5, 20.0, c.damage,
                v -> c.damage = v));

        addDrawableChild(ButtonWidget.builder(label("Barrido", c.sweep), b -> {
            c.sweep = !c.sweep;
            b.setMessage(label("Barrido", c.sweep));
        }).dimensions(x, y + step * 2, w, 20).build());

        addDrawableChild(new ValueSlider(x, y + step * 3, w, 20, "Dano barrido", 0.0, 10.0,
                c.sweepDamage, v -> c.sweepDamage = v));

        addDrawableChild(ButtonWidget.builder(label("Solo mobs hostiles", c.hostileOnly), b -> {
            c.hostileOnly = !c.hostileOnly;
            b.setMessage(label("Solo mobs hostiles", c.hostileOnly));
        }).dimensions(x, y + step * 4, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Listo"), b -> close())
                .dimensions(x, y + step * 5 + 6, w, 20).build());
    }

    private static Text label(String name, boolean value) {
        return Text.literal(name + ": " + (value ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);
    }

    @Override
    public void close() {
        TriggerBotConfig.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }

    private static class ValueSlider extends SliderWidget {
        private final String name;
        private final double min;
        private final double max;
        private final Consumer<Float> setter;

        ValueSlider(int x, int y, int width, int height, String name,
                    double min, double max, double current, Consumer<Float> setter) {
            super(x, y, width, height, Text.empty(), (current - min) / (max - min));
            this.name = name;
            this.min = min;
            this.max = max;
            this.setter = setter;
            updateMessage();
        }

        private float val() {
            return (float) (Math.round((min + (max - min) * this.value) * 10.0) / 10.0);
        }

        @Override
        protected void updateMessage() {
            if (name == null) return;
            setMessage(Text.literal(name + ": " + val()));
        }

        @Override
        protected void applyValue() {
            setter.accept(val());
        }
    }
}
