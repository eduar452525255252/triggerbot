package com.example.triggerbot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class TriggerBotConfig {
    public boolean enabled = false;
    public float damage = 3.4f;
    public boolean sweep = true;
    public float sweepDamage = 1.0f;
    public boolean hostileOnly = false;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH =
            FabricLoader.getInstance().getConfigDir().resolve("triggerbot.json");

    public static TriggerBotConfig INSTANCE = load();

    public static TriggerBotConfig load() {
        try {
            if (Files.exists(PATH)) {
                TriggerBotConfig c = GSON.fromJson(Files.readString(PATH), TriggerBotConfig.class);
                if (c != null) return c;
            }
        } catch (Exception ignored) {
        }
        return new TriggerBotConfig();
    }

    public static void save() {
        try {
            Files.writeString(PATH, GSON.toJson(INSTANCE));
        } catch (IOException ignored) {
        }
    }
}
