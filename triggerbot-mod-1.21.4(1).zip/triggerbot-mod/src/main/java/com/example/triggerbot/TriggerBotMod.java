package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;

public class TriggerBotMod implements ClientModInitializer {

    private static KeyBinding toggleKey;
    private static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_CONTROL, "category.triggerbot"));

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.menu", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.triggerbot"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            TriggerBotConfig cfg = TriggerBotConfig.INSTANCE;

            while (menuKey.wasPressed()) {
                client.setScreen(new ConfigScreen(null));
            }

            while (toggleKey.wasPressed()) {
                cfg.enabled = !cfg.enabled;
                TriggerBotConfig.save();
                if (client.player != null) {
                    client.player.sendMessage(
                            Text.literal("TriggerBot: " + (cfg.enabled ? "ON" : "OFF")), true);
                }
            }

            if (!cfg.enabled
                    || client.player == null
                    || client.world == null
                    || client.currentScreen != null) {
                return;
            }

            // Solo funciona con servidor integrado (singleplayer / LAN)
            MinecraftServer server = client.getServer();
            if (server == null) return;

            if (!(client.crosshairTarget instanceof EntityHitResult hit)) return;

            if (cfg.hostileOnly && !(hit.getEntity() instanceof HostileEntity)) return;

            // Solo con espada en la mano principal
            if (!client.player.getMainHandStack().isIn(ItemTags.SWORDS)) return;

            // Solo con el golpe completamente cargado
            if (client.player.getAttackCooldownProgress(0.5f) < 1.0f) return;

            int targetId = hit.getEntity().getId();
            UUID playerId = client.player.getUuid();
            float damage = cfg.damage;
            boolean sweep = cfg.sweep;
            float sweepDamage = cfg.sweepDamage;

            server.execute(() -> {
                ServerPlayerEntity player = server.getPlayerManager().getPlayer(playerId);
                if (player == null) return;

                ServerWorld world = player.getServerWorld();
                Entity target = world.getEntityById(targetId);
                if (target == null || !target.isAlive() || !target.isAttackable()) return;

                target.damage(world, world.getDamageSources().playerAttack(player), damage);

                // Barrido: solo si esta en el suelo (no saltando ni cayendo)
                if (sweep && player.isOnGround() && !player.isClimbing() && !player.isTouchingWater()) {
                    float yawRad = player.getYaw() * ((float) Math.PI / 180f);
                    double kbX = MathHelper.sin(yawRad);
                    double kbZ = -MathHelper.cos(yawRad);

                    for (LivingEntity other : world.getNonSpectatingEntities(
                            LivingEntity.class,
                            target.getBoundingBox().expand(1.0, 0.25, 1.0))) {

                        if (other == player || other == target) continue;
                        if (player.isTeammate(other)) continue;
                        if (other instanceof ArmorStandEntity stand && stand.isMarker()) continue;
                        if (player.squaredDistanceTo(other) >= 9.0) continue;
                        if (!other.isAlive() || !other.isAttackable()) continue;

                        other.takeKnockback(0.4, kbX, kbZ);
                        other.damage(world, world.getDamageSources().playerAttack(player), sweepDamage);
                    }

                    world.playSound(null, player.getX(), player.getY(), player.getZ(),
                            SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.0f, 1.0f);
                    player.spawnSweepAttackParticles();
                }
            });

            client.player.swingHand(Hand.MAIN_HAND);
            client.player.resetLastAttackedTicks();
        });
    }
}
